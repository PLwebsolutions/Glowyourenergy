# GlowYourEnergy — website van Nikola

Statische HTML-site. Geen build-stap, geen framework. Upload de hele map naar je hosting
en de site werkt. Test lokaal door `index.html` in je browser te openen.

## Wat er in zit

| Bestand | Pagina |
|---|---|
| `index.html` | Home |
| `over-nikola.html` | Over Nikola (met jouw eigen tekst) |
| `reiki.html` | Wat is Reiki + de zeven chakra's |
| `diensten.html` | De vier behandelingen, tarieven en praktische zaken |
| `vragen.html` | 20 veelgestelde vragen (met FAQ-schema voor Google) |
| `contact.html` | Contactformulier + gegevens |
| `bedankt.html` | Bedankpagina na verzenden |
| `privacy.html` · `algemene-voorwaarden.html` | Juridische basisteksten |
| `sitemap.xml` · `robots.txt` | Voor Google |
| `404.html` | Foutpagina (wijs je server hiernaartoe) |
| `site.webmanifest` | Voor "toevoegen aan beginscherm" op mobiel |
| `assets/` | CSS, JavaScript, 17 foto's |

---

## Voor livegang invullen — loop deze lijst af

### 1. Contactgegevens
Telefoonnummer, WhatsApp en adres staan er goed in:
Hellingshoeve 4 in Helmond, 06 45 48 02 29, WhatsApp naar `wa.me/31645480229`.
De postcode staat er nog niet in; die hoort in het adresblok van `contact.html`
en in het JSON-LD-schema bovenaan elke pagina (`address`).

Wat nog wel op nep-waarden staat:
Zoek en vervang in **alle** HTML-bestanden:

| Zoek | Vervang door |
|---|---|
| `hallo@glowyourenergy.nl` | je echte e-mailadres |
| `https://www.glowyourenergy.nl` | je echte domeinnaam |
| `KvK 00000000` | je KvK-nummer |
| `https://www.instagram.com/` | je Instagram-profiel |

Op één regel in de terminal:
```bash
grep -rl "glowyourenergy.nl" . | xargs sed -i '' 's/www.glowyourenergy.nl/jouwdomein.nl/g'
```

### 2. Blokken tussen vierkante haken
Overal waar `[ ... ]` staat moet jouw informatie komen. Zoek op `[ ` om ze te vinden.
Ze staan op: **Over Nikola** (opleidingen), **Sessies** (adres, parkeren, vergoeding),
**Vragen** (Reiki op afstand, vergoeding), **Privacy** en **Algemene voorwaarden**.

### 3. Opleidingen — belangrijk
Op `over-nikola.html` staat een tabel "Opleiding & achtergrond" die nog leeg is.
Vul daar **alleen** in wat je daadwerkelijk hebt afgerond, met de juiste opleider en
het juiste jaartal. Onjuiste opleidingsclaims op een zorggerelateerde website leveren
serieus gedoe op.

Wil je je certificaten tonen? Fotografeer ze en **dek eerst je geboortedatum,
geboorteplaats en documentnummers af** — die horen niet op een openbare website.
Zet ze daarna in `assets/img/` en plaats ze met het `.cred`-blok dat in de CSS klaarstaat.

### 4. Ervaringen van cliënten
De drie ervaringen op de homepage zijn **voorbeelden** en moeten weg. Vraag drie klanten
om toestemming en zet hun eigen woorden erin. Verzonnen reviews zijn misleidend en in
Nederland verboden onder de Wet oneerlijke handelspraktijken.

### 5. Tarieven — staan er goed in
| Behandeling | Duur | Prijs |
|---|---|---|
| Eerste consult met chakrascan | 60 min | € 45 |
| Reiki-behandeling | 60 min | € 70 |
| Klankschaalmassage | 60 min | € 77 |
| Innerlijk kind werk | 45 min | € 60 |
| Uitloop | per kwartier | € 10 |

Wijzig je een prijs, pas hem dan op vier plekken aan: `index.html`, `diensten.html`,
`vragen.html` en het JSON-LD-schema bovenaan `index.html` en `diensten.html`.
Dat laatste is wat Google uitleest en in de zoekresultaten kan tonen.

### 6. Contactformulier laten werken
Nu opent het formulier het mailprogramma van de bezoeker. Dat werkt, maar is niet ideaal.
Beter: maak een gratis account bij **Formspree** of **Tally** en zet het adres dat je
krijgt in `contact.html`:

```html
<form class="form" data-validate action="https://formspree.io/f/JOUWCODE" method="post" novalidate>
```

Voeg er dit veld aan toe zodat mensen op de bedankpagina landen:
```html
<input type="hidden" name="_next" value="https://jouwdomein.nl/bedankt.html">
```

### 7. WhatsApp-knop
De groene knop rechtsonder leidt naar `wa.me/31645480229`. Wil je dat het bericht
alvast is ingevuld, zet er dan achter:
`?text=Hoi%20Nikola,%20ik%20heb%20een%20vraag`.

### 8. Google
1. Zet de site live met https.
2. Meld je aan bij Google Search Console en dien `sitemap.xml` in.
3. Maak een **Google Bedrijfsprofiel** aan. Voor een lokale praktijk levert dat meer
   klanten op dan de website zelf. Zorg dat naam, adres en telefoonnummer daar exact
   gelijk zijn aan wat op deze site staat.

### 9. Serverinstellingen
Laat je hosting `404.html` gebruiken als foutpagina. Bij Apache zet je in `.htaccess`:
`ErrorDocument 404 /404.html`. Bij Netlify of Vercel gaat dit vanzelf.

---

## Ontwerp

**Kleuren** volgen jouw palet: zand (#FFDCAD), zandgoud (#FFB257) en een dieper
accentgoud (#C9A24A / #A8842F) voor knoppen en links. Er zit bewust geen fel oranje
in — de donkere vlakken zijn geroosterd brons (#2B2114) in plaats van blauw, zodat
alles binnen dezelfde warme familie blijft. De chakra-kleuren zijn gedempt naar
aardtinten, zodat de pagina goud en zand blijft.

**Typografie**: Fraunces (koppen) en Karla (tekst), via Google Fonts.

**Beeld**: de handenfoto met het licht opent de homepage en komt onderaan elke
pagina zacht terug, wegvloeiend in de voettekst, met de regel "Je mag weer stralen".

**Vorm**: de boog. Portretfoto's staan in een gewelfde lijst, als een nis. Die vorm
komt terug in de knoppen en de onderkant van de tariefkaarten.

**Animaties**: hero die getrapt opkomt, boogfoto's die zich van onder naar boven
openvouwen, secties die binnenzweven bij scrollen, parallax op de grote sfeerbeelden,
drijvende gloed achter de donkere secties, tellers die oplopen, chakra-stippen die
oppoppen, een sfeerstrook die langzaam doorschuift (stopt als je erover zweeft),
gloed die de muis volgt over de tariefkaarten, ademend zonnetje, pulserende
WhatsApp-knop. Alles schakelt automatisch uit voor bezoekers die in hun systeem
"verminder beweging" hebben aanstaan.

**Interactie**: leesvoortgangsbalk bovenin, klikbare galerij met lightbox
(sluiten met Escape, bedienbaar met toetsenbord), terug-naar-boven-knop,
bereikbaarheidsmelding die zichzelf bijwerkt op basis van je openingstijden.

**Foto's**: uit je zes originelen heb ik elf detailuitsnedes gemaakt, zodat elke
pagina eigen beeld heeft en geen enkele foto twee keer prominent terugkomt.

### Kleuren aanpassen
Alles staat bovenin `assets/css/style.css` onder `:root`. Verander daar één waarde en
de hele site verandert mee.

---

## Techniek

- Werkt vanaf ~320px breed tot ultrawide.
- Toetsenbordbediening en zichtbare focusrand.
- Eén `<h1>` per pagina, logische kopstructuur, alt-teksten op alle foto's.
- Schema.org: bedrijf, persoon, diensten, prijzen en FAQ.
- Open Graph-afbeelding voor WhatsApp en social.
- Geen cookies, geen trackers, geen externe scripts behalve Google Fonts.
  Wil je ook dat laatste weg: download de fonts en host ze zelf, dan heb je helemaal
  geen cookiebanner nodig.

## Nog wat kan groeien

De site is af en kan live. Wat later omzet toevoegt:
- Een online agenda waarin mensen zelf een tijdslot kiezen (scheelt heen-en-weer mailen).
- Een blog of "verhalen"-pagina — goed voor Google en voor vertrouwen.
- Echte praktijkfoto's van de behandelruimte. Mensen willen zien waar ze gaan liggen.
- Een cadeaubon. Rond de feestdagen verkoopt die zichzelf.
