/* Nikola — Reiki & Holistische Begeleiding
   Kleine, afhankelijkheidsvrije interacties. */

(function () {
  'use strict';

  /* ---------- Intro met het logo ----------
     De animatie zelf staat in de CSS. Hier zetten we alleen
     de pagina even stil en ruimen we het scherm daarna op. */
  var intro = document.querySelector('.intro');
  if (intro) {
    var stil = !window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (stil) {
      document.body.classList.add('intro-actief');
      window.setTimeout(function () {
        document.body.classList.remove('intro-actief');
      }, 1700);
    }
    window.setTimeout(function () {
      if (intro.parentNode) intro.parentNode.removeChild(intro);
    }, stil ? 2700 : 100);
  }

  /* ---------- Mobiele navigatie ---------- */
  var toggle = document.querySelector('.menu-toggle');
  var panel = document.getElementById('mobile-nav');

  function setNav(open) {
    if (!toggle || !panel) return;
    toggle.setAttribute('aria-expanded', String(open));
    panel.classList.toggle('is-open', open);
    panel.setAttribute('aria-hidden', String(!open));
    document.body.classList.toggle('nav-open', open);
    toggle.querySelector('.label').textContent = open ? 'Sluiten' : 'Menu';
  }

  if (toggle && panel) {
    setNav(false);
    toggle.addEventListener('click', function () {
      setNav(toggle.getAttribute('aria-expanded') !== 'true');
    });
    panel.addEventListener('click', function (e) {
      if (e.target.closest('a')) setNav(false);
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && panel.classList.contains('is-open')) {
        setNav(false);
        toggle.focus();
      }
    });
  }

  /* ---------- Header krijgt achtergrond zodra je scrollt ---------- */
  var header = document.querySelector('.site-header');
  var toTop = document.querySelector('.fab--top');
  var bookBar = document.querySelector('.book-bar');
  var bar = document.querySelector('.progress i');
  var ring = document.querySelector('.fab__ring-actief');
  var RING_OMTREK = 2 * Math.PI * 22;
  var ticking = false;

  function onScroll() {
    var y = window.scrollY;
    if (header) header.classList.toggle('is-stuck', y > 40);
    if (toTop) toTop.classList.toggle('is-visible', y > 700);
    if (bookBar) bookBar.classList.toggle('is-visible', y > 700);
    var hoogte = document.documentElement.scrollHeight - window.innerHeight;
    var deel = hoogte > 0 ? Math.min(Math.max(y / hoogte, 0), 1) : 0;
    if (bar) bar.style.width = (deel * 100).toFixed(2) + '%';
    if (ring) ring.style.strokeDashoffset = (RING_OMTREK * (1 - deel)).toFixed(2);
    parallax(y);
    ticking = false;
  }
  function vraagFrame() {
    if (!ticking) { ticking = true; requestAnimationFrame(onScroll); }
  }
  window.addEventListener('scroll', vraagFrame, { passive: true });
  window.addEventListener('resize', vraagFrame, { passive: true });

  if (toTop) {
    toTop.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: reducedMotion() ? 'auto' : 'smooth' });
    });
  }

  function reducedMotion() {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  }

  /* ---------- Zachte diepte op grote sfeerbeelden ---------- */
  var lagen = [];
  function verzamelParallax() {
    lagen = Array.prototype.slice.call(document.querySelectorAll('.parallax'))
      .filter(function (el) { return !el.closest('.hero'); });
  }
  function parallax(y) {
    if (reducedMotion() || window.innerWidth < 760) return;
    lagen.forEach(function (el) {
      var doos = el.getBoundingClientRect();
      if (doos.bottom < -200 || doos.top > window.innerHeight + 200) return;
      var midden = doos.top + doos.height / 2 - window.innerHeight / 2;
      el.style.transform = 'translate3d(0,' + (midden * -0.042).toFixed(1) + 'px,0) scale(1.1)';
    });
  }
  verzamelParallax();
  window.verzamelParallax = verzamelParallax;

  /* ---------- Foto-fallback ----------
     Zolang een foto nog niet is toegevoegd tonen we een warme
     gradient in plaats van een gebroken afbeelding. */
  document.querySelectorAll('.photo img').forEach(function (img) {
    function fail() {
      var box = img.closest('.photo');
      if (box) box.classList.add('photo--empty');
    }
    img.addEventListener('error', fail);
    if (img.complete && img.naturalWidth === 0) fail();
  });

  var heroImg = document.querySelector('.hero__media img');
  if (heroImg) {
    heroImg.addEventListener('error', function () { heroImg.style.display = 'none'; });
    if (heroImg.complete && heroImg.naturalWidth === 0) heroImg.style.display = 'none';
  }

  /* ---------- Contactformulier ---------- */
  var form = document.querySelector('form[data-validate]');
  if (form) {
    var status = form.querySelector('.form-status');

    var rules = {
      naam: function (v) { return v.trim().length >= 2 || 'Vul je naam in.'; },
      email: function (v) { return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) || 'Vul een geldig e-mailadres in.'; },
      bericht: function (v) { return v.trim().length >= 10 || 'Schrijf kort waar je voor komt (minimaal 10 tekens).'; },
      privacy: function (v, el) { return el.checked || 'Geef aan dat je akkoord gaat met de privacyverklaring.'; }
    };

    function validateField(el) {
      var rule = rules[el.name];
      if (!rule) return true;
      var result = rule(el.value, el);
      var msg = el.closest('.field, .check').querySelector('.err');
      if (result === true) {
        el.removeAttribute('aria-invalid');
        if (msg) msg.textContent = '';
        return true;
      }
      el.setAttribute('aria-invalid', 'true');
      if (msg) msg.textContent = result;
      return false;
    }

    form.querySelectorAll('[name]').forEach(function (el) {
      el.addEventListener('blur', function () { validateField(el); });
      el.addEventListener('input', function () {
        if (el.getAttribute('aria-invalid') === 'true') validateField(el);
      });
    });

    form.addEventListener('submit', function (e) {
      var ok = true;
      var first = null;
      form.querySelectorAll('[name]').forEach(function (el) {
        if (!validateField(el)) { ok = false; if (!first) first = el; }
      });

      // Honeypot tegen spam
      var trap = form.querySelector('input[name="_gotcha"]');
      if (trap && trap.value) { e.preventDefault(); return; }

      if (!ok) {
        e.preventDefault();
        if (first) first.focus();
        if (status) {
          status.hidden = false;
          status.textContent = 'Er ontbreekt nog iets. Kijk je even naar de gemarkeerde velden?';
        }
        return;
      }

      // Zolang er geen verzendadres is ingesteld: openen in e-mailprogramma.
      if (!form.getAttribute('action') || form.getAttribute('action') === '#') {
        e.preventDefault();
        var data = new FormData(form);
        var body = [
          'Naam: ' + (data.get('naam') || ''),
          'E-mail: ' + (data.get('email') || ''),
          'Telefoon: ' + (data.get('telefoon') || ''),
          'Interesse: ' + (data.get('sessie') || ''),
          '',
          data.get('bericht') || ''
        ].join('\n');
        window.location.href = 'mailto:' + (form.dataset.mailto || 'hallo@example.com') +
          '?subject=' + encodeURIComponent('Aanvraag via de website') +
          '&body=' + encodeURIComponent(body);
        if (status) {
          status.hidden = false;
          status.textContent = 'Je e-mailprogramma opent met je bericht. Verstuur het daar om het af te ronden.';
        }
      }
    });
  }

  /* ---------- Verschijnen bij scrollen ---------- */
  var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var io = null;

  if (!reduced && 'IntersectionObserver' in window) {
    io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-in');
        io.unobserve(entry.target);
      });
    }, { rootMargin: '0px 0px -12% 0px', threshold: 0.12 });
  }

  function scanReveals(root) {
    var els = (root || document).querySelectorAll('[data-reveal], .line-mask');
    if (!io) {
      els.forEach(function (el) { el.classList.add('is-in'); });
      return;
    }
    els.forEach(function (el) {
      if (el.classList.contains('is-in')) return;
      if (!el.style.getPropertyValue('--delay')) {
        var group = el.parentElement;
        var siblings = group ? group.querySelectorAll(':scope > [data-reveal]') : [];
        if (siblings.length > 1) {
          var idx = Array.prototype.indexOf.call(siblings, el);
          if (idx > 0) el.style.setProperty('--delay', (idx * 110) + 'ms');
        }
      }
      io.observe(el);
    });
  }
  window.scanReveals = scanReveals;
  scanReveals(document);
  onScroll();

  /* ---------- Tellers ---------- */
  var counters = document.querySelectorAll('[data-count]');
  if (counters.length) {
    if (reduced || !('IntersectionObserver' in window)) {
      counters.forEach(function (el) { el.textContent = el.dataset.count + (el.dataset.suffix || ''); });
    } else {
      var co = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (!entry.isIntersecting) return;
          var el = entry.target;
          co.unobserve(el);
          var target = parseFloat(el.dataset.count);
          var suffix = el.dataset.suffix || '';
          var start = performance.now();
          var dur = 1400;
          (function tick(now) {
            var p = Math.min((now - start) / dur, 1);
            var eased = 1 - Math.pow(1 - p, 3);
            el.textContent = Math.round(target * eased) + suffix;
            if (p < 1) requestAnimationFrame(tick);
          })(start);
        });
      }, { threshold: 0.5 });
      counters.forEach(function (el) { co.observe(el); });
    }
  }

  /* ---------- Lightbox voor de galerij ---------- */
  var box = document.querySelector('.lightbox');
  if (box) {
    var boxImg = box.querySelector('img');
    var boxCap = box.querySelector('.lightbox__caption');
    var laatsteKnop = null;

    function open(bron, tekst, knop) {
      boxImg.src = bron;
      boxImg.alt = tekst || '';
      boxCap.textContent = tekst || '';
      box.classList.add('is-open');
      document.body.classList.add('nav-open');
      laatsteKnop = knop || null;
      box.querySelector('.lightbox__close').focus();
    }
    function sluit() {
      box.classList.remove('is-open');
      document.body.classList.remove('nav-open');
      if (laatsteKnop) laatsteKnop.focus();
    }

    document.addEventListener('click', function (e) {
      var trigger = e.target.closest('.gallery .photo');
      if (trigger) {
        var img = trigger.querySelector('img');
        if (img && img.currentSrc !== '') open(img.currentSrc || img.src, img.alt, trigger);
        return;
      }
      if (e.target.closest('.lightbox__close') || e.target === box) sluit();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && box.classList.contains('is-open')) sluit();
    });

    // Foto's in de galerij zijn met het toetsenbord te bedienen
    document.querySelectorAll('.gallery .photo').forEach(function (el) {
      el.setAttribute('tabindex', '0');
      el.setAttribute('role', 'button');
      el.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); el.click(); }
      });
    });
  }

  /* ---------- Gloed die de muis volgt over de tariefkaarten ---------- */
  document.querySelectorAll('.tier').forEach(function (kaart) {
    kaart.addEventListener('pointermove', function (e) {
      var d = kaart.getBoundingClientRect();
      kaart.style.setProperty('--mx', (e.clientX - d.left) + 'px');
      kaart.style.setProperty('--my', (e.clientY - d.top) + 'px');
    });
  });

  /* ---------- Vandaag geopend? ---------- */
  document.querySelectorAll('[data-open-status]').forEach(function (el) {
    var nu = new Date();
    var dag = nu.getDay();
    var uur = nu.getHours() + nu.getMinutes() / 60;
    var open = (dag >= 1 && dag <= 5 && uur >= 9 && uur < 20) || (dag === 6 && uur >= 10 && uur < 15);
    el.querySelector('span').textContent = open ? 'Nu bereikbaar' : 'Nu gesloten, stuur gerust een bericht';
  });

  /* ---------- Huidig jaar in de footer ---------- */
  document.querySelectorAll('[data-year]').forEach(function (el) {
    el.textContent = new Date().getFullYear();
  });
})();
