/* GlowYourEnergy — bewegingslaag
   Vloeiend scrollen, scroll-gestuurde beelden, tekst die woord voor
   woord opkomt en zachte hover-reacties. Alles zonder externe
   bibliotheken, en alles valt stil bij "verminder beweging". */

(function () {
  'use strict';

  var rustig = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var fijnAanwijzer = window.matchMedia('(pointer: fine)').matches;
  var breed = window.innerWidth >= 1024;

  /* =========================================================
     1. Vloeiend scrollen
     Alleen op desktop met muis. Op aanraakschermen laten we het
     eigen momentum van het toestel met rust, dat voelt beter.
     ========================================================= */
  var soepel = !rustig && fijnAanwijzer && breed;
  var doel = window.scrollY;
  var huidig = window.scrollY;
  var loopt = false;
  var laatsteEigenSprong = 0;

  function maximum() {
    return Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
  }

  function stap() {
    huidig += (doel - huidig) * 0.115;
    if (Math.abs(doel - huidig) < 0.4) { huidig = doel; loopt = false; }
    laatsteEigenSprong = performance.now();
    window.scrollTo(0, huidig);
    tekenScroll(huidig);
    if (loopt) requestAnimationFrame(stap);
  }

  function zetInGang() {
    if (!loopt) { loopt = true; requestAnimationFrame(stap); }
  }

  if (soepel) {
    document.documentElement.style.scrollBehavior = 'auto';

    window.addEventListener('wheel', function (e) {
      if (e.ctrlKey || !e.cancelable) return;
      if (document.body.classList.contains('nav-open')) return;
      e.preventDefault();
      var stapGrootte = e.deltaMode === 1 ? 18 : (e.deltaMode === 2 ? window.innerHeight : 1);
      doel = Math.min(Math.max(0, doel + e.deltaY * stapGrootte), maximum());
      zetInGang();
    }, { passive: false });

    // Toetsenbord, ankerlinks en de knop terug naar boven springen
    // buiten ons om. Daar lopen we netjes achteraan.
    window.addEventListener('scroll', function () {
      if (performance.now() - laatsteEigenSprong < 120) return;
      doel = huidig = window.scrollY;
    }, { passive: true });

    window.addEventListener('resize', function () {
      doel = huidig = window.scrollY;
    }, { passive: true });
  }

  /* =========================================================
     2. Scroll-gestuurde beelden
     Eén tekenlus voor alle bewegende onderdelen.
     ========================================================= */
  var lagen = [];

  function verzamel() {
    lagen = [];
    if (rustig) return;

    document.querySelectorAll('[data-beweeg]').forEach(function (el) {
      if (el.closest('.page[hidden]')) return;
      lagen.push({
        el: el,
        soort: el.dataset.beweeg,
        kracht: parseFloat(el.dataset.kracht || '1')
      });
    });
  }

  function tekenScroll() {
    if (!lagen.length) return;
    var hoogte = window.innerHeight;
    var mobiel = window.innerWidth < 760;

    for (var i = 0; i < lagen.length; i++) {
      var laag = lagen[i];
      var doos = laag.el.getBoundingClientRect();
      if (doos.bottom < -200 || doos.top > hoogte + 200) continue;

      if (laag.soort === 'parallax') {
        if (mobiel) { laag.el.style.transform = ''; continue; }
        var midden = doos.top + doos.height / 2 - hoogte / 2;
        laag.el.style.transform =
          'translate3d(0,' + (midden * -0.04 * laag.kracht).toFixed(1) + 'px,0) scale(1.09)';

      } else if (laag.soort === 'hero-media') {
        // De hero verlaat het beeld: het beeld schaalt langzaam op
        // en dooft, terwijl de volgende sectie eroverheen schuift.
        var voortgang = Math.min(Math.max(-doos.top / Math.max(doos.height, 1), 0), 1);
        var soepelheid = voortgang * voortgang * (3 - 2 * voortgang);
        laag.el.style.transform = 'scale(' + (1 + soepelheid * 0.09).toFixed(4) + ')';
        laag.el.style.opacity = (1 - soepelheid * 0.45).toFixed(3);

      } else if (laag.soort === 'hero-inhoud') {
        var v2 = Math.min(Math.max(-doos.top / (hoogte * 0.8), 0), 1);
        laag.el.style.transform = 'translate3d(0,' + (v2 * -40).toFixed(1) + 'px,0)';
        laag.el.style.opacity = (1 - v2 * 0.9).toFixed(3);
      }
    }
  }

  var wachtOpFrame = false;
  function vraagTekening() {
    if (wachtOpFrame) return;
    wachtOpFrame = true;
    requestAnimationFrame(function () { tekenScroll(); wachtOpFrame = false; });
  }

  verzamel();
  tekenScroll();
  if (!soepel) window.addEventListener('scroll', vraagTekening, { passive: true });
  window.addEventListener('resize', function () { verzamel(); vraagTekening(); }, { passive: true });
  window.verzamelBeweging = function () { verzamel(); vraagTekening(); };

  /* =========================================================
     3. Koppen die woord voor woord opkomen
     De tekst blijft één geheel voor schermlezers en zoekmachines,
     we verpakken alleen de losse woorden.
     ========================================================= */
  function splits(kop) {
    if (rustig || kop.dataset.gesplitst) return;
    if (kop.querySelector('img, svg, br')) return;
    var tekst = kop.textContent.trim();
    if (!tekst || tekst.length > 120) return;

    kop.dataset.gesplitst = '1';
    kop.setAttribute('aria-label', tekst);
    var woorden = tekst.split(/\s+/);
    kop.textContent = '';
    woorden.forEach(function (woord, i) {
      // Lange samenstellingen laten we ongemoeid: in een masker
      // verpakt kunnen ze niet meer afbreken en lopen ze het
      // vak uit.
      if (woord.length > 15) {
        kop.appendChild(document.createTextNode(woord));
        if (i < woorden.length - 1) kop.appendChild(document.createTextNode(' '));
        return;
      }
      var buiten = document.createElement('span');
      buiten.className = 'w';
      buiten.setAttribute('aria-hidden', 'true');
      var binnen = document.createElement('span');
      binnen.className = 'wi';
      binnen.style.transitionDelay = (i * 55) + 'ms';
      binnen.textContent = woord;
      buiten.appendChild(binnen);
      kop.appendChild(buiten);
      if (i < woorden.length - 1) kop.appendChild(document.createTextNode(' '));
    });

    // De omhullende sectie mag dan niet óók verschuiven,
    // anders bewegen er twee dingen tegelijk.
    var ouder = kop.closest('[data-reveal]');
    if (ouder && ouder.dataset.reveal !== 'fade') ouder.dataset.reveal = 'fade';
  }

  function splitsAlles(bereik) {
    (bereik || document).querySelectorAll('.hero h1, section h2').forEach(splits);
  }
  splitsAlles(document);
  window.splitsKoppen = splitsAlles;

  /* =========================================================
     4. Lijstregels en sierlijnen komen na elkaar in beeld
     ========================================================= */
  function markeer(bereik) {
    var wortel = bereik || document;
    wortel.querySelectorAll('.sunrule').forEach(function (el) {
      if (!el.hasAttribute('data-reveal')) el.setAttribute('data-reveal', 'fade');
    });
    ['.reasons li', '.chakras li', '.rows > div', '.trustbar li', '.faq details'].forEach(function (kies) {
      wortel.querySelectorAll(kies).forEach(function (el, i) {
        if (el.hasAttribute('data-reveal')) return;
        el.setAttribute('data-reveal', 'los');
        el.style.setProperty('--delay', Math.min(i, 8) * 65 + 'ms');
      });
    });
    if (window.scanReveals) window.scanReveals(wortel);
  }
  markeer(document);
  window.markeerRegels = markeer;

  /* =========================================================
     5. Knoppen die zachtjes naar de muis toe bewegen
     ========================================================= */
  if (!rustig && fijnAanwijzer) {
    document.querySelectorAll('.btn').forEach(function (knop) {
      var actief = false;
      knop.addEventListener('pointerenter', function () { actief = true; });
      knop.addEventListener('pointermove', function (e) {
        if (!actief) return;
        var d = knop.getBoundingClientRect();
        var x = (e.clientX - d.left - d.width / 2) / d.width;
        var y = (e.clientY - d.top - d.height / 2) / d.height;
        knop.style.transform = 'translate3d(' + (x * 5).toFixed(1) + 'px,' +
          (y * 3 - 2).toFixed(1) + 'px,0)';
      });
      knop.addEventListener('pointerleave', function () {
        actief = false;
        knop.style.transform = '';
      });
    });
  }
})();
